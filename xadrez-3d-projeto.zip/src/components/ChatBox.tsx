import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, ChevronDown, ChevronUp, Send, Sparkles } from 'lucide-react';
import { BotProfile } from '../types/chess';

export interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  color?: string;
  avatar?: string;
  isBot?: boolean;
}

interface ChatBoxProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  botProfile?: BotProfile | null;
  gameMode: string;
}

export const ChatBox: React.FC<ChatBoxProps> = ({
  messages,
  onSendMessage,
  botProfile,
  gameMode
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, collapsed]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    onSendMessage(inputValue.trim());
    setInputValue('');
  };

  const quickReactions = [
    'Boa jogada! 👏',
    'Xeque! ⚔️',
    'Opa! 😮',
    'Vamos ver! 🤔',
    'Bom jogo! 🤝'
  ];

  return (
    <div className="fixed bottom-4 left-4 z-20 w-80 max-w-[calc(100vw-2rem)] bg-[#09152e]/90 border border-blue-900/60 backdrop-blur-xl rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-all duration-300">
      {/* Header */}
      <div className="bg-[#0b1b3d] px-3.5 py-2.5 border-b border-blue-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {botProfile ? (
            <div className="w-5 h-5 rounded-full flex items-center justify-center text-xs bg-blue-600/30 border border-blue-400/40">
              {botProfile.avatar}
            </div>
          ) : (
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
          )}
          <span className="text-xs font-bold text-slate-100 truncate">
            {botProfile ? `Chat - ${botProfile.name}` : 'Chat da Partida'}
          </span>
        </div>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-blue-900/40 transition-colors"
          title={collapsed ? 'Expandir Chat' : 'Recolher Chat'}
        >
          {collapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {!collapsed && (
        <>
          {/* Messages list */}
          <div className="h-36 overflow-y-auto p-3 flex flex-col gap-2.5 text-xs">
            {messages.map((m) => (
              <div key={m.id} className="flex flex-col gap-0.5 leading-snug">
                <div className="flex items-center gap-1.5">
                  {m.avatar && <span className="text-xs">{m.avatar}</span>}
                  <span
                    className="font-bold text-[11px]"
                    style={{ color: m.color || (m.isBot ? '#38bdf8' : '#a5b4fc') }}
                  >
                    {m.sender}
                  </span>
                </div>
                <div className="text-slate-200 text-xs bg-blue-950/50 border border-blue-900/40 p-2 rounded-xl rounded-tl-sm shadow-sm">
                  {m.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick reactions */}
          <div className="px-2.5 py-1.5 flex gap-1.5 overflow-x-auto no-scrollbar border-t border-blue-900/30 bg-[#071329]">
            {quickReactions.map((reaction, i) => (
              <button
                key={i}
                type="button"
                onClick={() => onSendMessage(reaction)}
                className="px-2 py-1 rounded-lg bg-blue-900/30 hover:bg-blue-800/50 text-[10px] text-cyan-200 whitespace-nowrap border border-blue-800/30 cursor-pointer transition-colors"
              >
                {reaction}
              </button>
            ))}
          </div>

          {/* Input form */}
          <form onSubmit={handleSubmit} className="p-2 border-t border-blue-900/50 bg-[#071329] flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Digite no chat..."
              className="flex-1 bg-slate-950/70 border border-blue-900/60 px-3 py-1.5 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
            />
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center transition-all shadow-md shadow-blue-600/30 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </>
      )}
    </div>
  );
};
