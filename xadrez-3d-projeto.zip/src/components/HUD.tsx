import React, { useState } from 'react';
import {
  Home,
  RotateCcw,
  Volume2,
  VolumeX,
  Flag,
  Music,
  Copy,
  Check,
  Download,
  Share2,
  Users
} from 'lucide-react';
import { GameMode, PieceColor } from '../types/chess';
import { BOT_PROFILES } from '../utils/aiEngine';

interface HUDProps {
  gameMode: GameMode;
  botLevel: number;
  currentTurn: PieceColor;
  playerColor: PieceColor;
  inCheck: boolean;
  onOpenMenu: () => void;
  onResetGame: () => void;
  onResign: () => void;
  onOpenAudioSettings: () => void;
  cameraPreset: 'white' | 'black' | 'top' | 'free';
  onSetCameraPreset: (preset: 'white' | 'black' | 'top' | 'free') => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onlineRoomCode: string | null;
  onOpenDownload: () => void;
  isOpponentConnected?: boolean;
}

export const HUD: React.FC<HUDProps> = ({
  gameMode,
  botLevel,
  currentTurn,
  playerColor,
  inCheck,
  onOpenMenu,
  onResetGame,
  onResign,
  onOpenAudioSettings,
  cameraPreset,
  onSetCameraPreset,
  isMuted,
  onToggleMute,
  onlineRoomCode,
  onOpenDownload,
  isOpponentConnected
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyCode = () => {
    if (onlineRoomCode) {
      navigator.clipboard.writeText(onlineRoomCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleCopyLink = () => {
    if (onlineRoomCode) {
      const shareUrl = `${window.location.origin}${window.location.pathname}?room=${onlineRoomCode}`;
      navigator.clipboard.writeText(shareUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const getModeTitle = () => {
    if (gameMode === 'BOT') {
      const bot = BOT_PROFILES[botLevel];
      return `vs ${bot?.name || 'Bot'} (Nível ${botLevel})`;
    }
    if (gameMode === 'ONLINE') {
      return `Amigo de Longe (${playerColor === 'w' ? 'Você é Brancas' : 'Você é Pretas'})`;
    }
    return `2 Jogadores Local`;
  };

  const getTurnStatusText = () => {
    if (inCheck) {
      return `XEQUE! Vez das ${currentTurn === 'w' ? 'Brancas' : 'Pretas'}`;
    }
    if (gameMode === 'ONLINE') {
      if (!isOpponentConnected) {
        return 'Aguardando seu amigo entrar... Envie o link ou código!';
      }
      const isMyTurn = currentTurn === playerColor;
      return isMyTurn
        ? `Sua vez de jogar (${playerColor === 'w' ? 'Brancas' : 'Pretas'})!`
        : `Aguardando jogada do adversário (${currentTurn === 'w' ? 'Brancas' : 'Pretas'})...`;
    }
    return `Vez das ${currentTurn === 'w' ? 'Brancas' : 'Pretas'}`;
  };

  return (
    <>
      {/* Main Top Bar */}
      <header className="fixed top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-3 bg-[#081329]/90 border border-blue-600/30 backdrop-blur-xl px-4 py-2.5 rounded-2xl shadow-2xl shadow-blue-950/60 max-w-[95vw]">
        {/* Menu button */}
        <button
          onClick={onOpenMenu}
          className="p-2 bg-blue-950/70 hover:bg-blue-900/60 rounded-xl text-slate-300 hover:text-white border border-blue-900/40 transition-all cursor-pointer"
          title="Menu Inicial"
        >
          <Home className="w-4 h-4" />
        </button>

        {/* Game Mode / Status */}
        <div className="flex items-center gap-2.5 border-l border-blue-900/50 pl-3">
          <div
            className={`w-3 h-3 rounded-full border ${
              currentTurn === 'w'
                ? 'bg-white border-slate-300 shadow-[0_0_8px_rgba(255,255,255,0.8)]'
                : 'bg-slate-900 border-cyan-400 shadow-[0_0_8px_rgba(56,189,248,0.8)]'
            }`}
          />
          <div className="flex flex-col">
            <h1 className="font-bold text-xs text-white leading-tight flex items-center gap-1.5">
              <span>{getModeTitle()}</span>
            </h1>
            <p
              className={`text-[11px] font-semibold tracking-wide ${
                inCheck
                  ? 'text-amber-400 animate-pulse font-bold'
                  : gameMode === 'ONLINE' && currentTurn === playerColor
                  ? 'text-emerald-400 font-bold'
                  : 'text-cyan-300'
              }`}
            >
              {getTurnStatusText()}
            </p>
          </div>
        </div>

        <div className="h-6 w-[1px] bg-blue-900/50 mx-1 hidden sm:block" />

        {/* Camera Views */}
        <div className="hidden sm:flex items-center gap-1 bg-blue-950/50 p-1 rounded-xl border border-blue-900/40">
          <button
            onClick={() => onSetCameraPreset('white')}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
              cameraPreset === 'white'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="Visão das Brancas"
          >
            Brancas
          </button>
          <button
            onClick={() => onSetCameraPreset('black')}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
              cameraPreset === 'black'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="Visão das Pretas"
          >
            Pretas
          </button>
          <button
            onClick={() => onSetCameraPreset('top')}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
              cameraPreset === 'top'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="Visão Superior 2D"
          >
            Tático 2D
          </button>
        </div>

        <div className="h-6 w-[1px] bg-blue-900/50 mx-1" />

        {/* Audio & Action Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onToggleMute}
            className="p-2 rounded-xl bg-blue-950/70 hover:bg-blue-900/60 text-slate-300 hover:text-cyan-300 border border-blue-900/40 transition-all cursor-pointer"
            title={isMuted ? 'Ativar Áudio' : 'Mutar Áudio'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={onOpenAudioSettings}
            className="p-2 rounded-xl bg-blue-950/70 hover:bg-blue-900/60 text-slate-300 hover:text-cyan-300 border border-blue-900/40 transition-all cursor-pointer"
            title="Configurar Sons & Músicas"
          >
            <Music className="w-4 h-4" />
          </button>

          {/* Download files */}
          <button
            onClick={onOpenDownload}
            className="p-2 rounded-xl bg-blue-600/30 hover:bg-blue-600/50 text-cyan-300 border border-blue-500/40 transition-all cursor-pointer"
            title="Baixar Arquivo do Site (.html / .zip)"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Restart */}
          <button
            onClick={onResetGame}
            className="p-2 rounded-xl bg-blue-950/70 hover:bg-blue-900/60 text-slate-300 hover:text-white border border-blue-900/40 transition-all cursor-pointer"
            title="Reiniciar Tabuleiro"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Resign */}
          <button
            onClick={onResign}
            className="p-2 rounded-xl bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-900/40 transition-all cursor-pointer"
            title="Render-se (Pegue seu banquinho)"
          >
            <Flag className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Online Room Badge with Direct Invite Link (Top Right) */}
      {onlineRoomCode && (
        <div className="fixed top-4 right-4 z-30 bg-[#081329]/95 border border-cyan-500/50 backdrop-blur-xl p-2.5 rounded-2xl shadow-xl flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div
              className={`w-2.5 h-2.5 rounded-full ${
                isOpponentConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400 animate-ping'
              }`}
            />
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] uppercase font-bold text-slate-400">Sala:</span>
                <span className="font-mono text-xs font-black text-cyan-300 tracking-wider">
                  {onlineRoomCode}
                </span>
              </div>
              <span className="text-[10px] text-blue-200/70">
                {isOpponentConnected ? 'Amigo conectado!' : 'Aguardando amigo...'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1 border-l border-blue-900/50 pl-2">
            {/* Copy Link Button */}
            <button
              onClick={handleCopyLink}
              className="px-2.5 py-1 bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-400/40 text-cyan-200 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
              title="Copiar link para convidar amigo"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              <span className="hidden md:inline">{copiedLink ? 'Copiado!' : 'Link'}</span>
            </button>

            {/* Copy Code Button */}
            <button
              onClick={handleCopyCode}
              className="px-2 py-1 bg-blue-950/60 hover:bg-blue-900/60 border border-blue-800 text-slate-300 hover:text-white rounded-lg text-xs font-medium flex items-center gap-1 cursor-pointer transition-colors"
              title="Copiar apenas o código"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="hidden md:inline">{copiedCode ? 'Copiado!' : 'Código'}</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
};
